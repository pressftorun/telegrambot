import telebot#кнопки тут чтоб не захламлять основной файл
from telebot import types
button1 = types.KeyboardButton('blank')
button2 = types.KeyboardButton('/addadmin')
button3 = types.KeyboardButton('/lk')
button4 = types.KeyboardButton('blank')
button5 = types.KeyboardButton('/addtask')
button6 = types.KeyboardButton('blank')
button7 = types.KeyboardButton('/removeusers')
button8 = types.KeyboardButton('/checktasks')
button9 = types.KeyboardButton('/deltask')
