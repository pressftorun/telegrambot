import telebot
from telebot import types
button1 = types.KeyboardButton('Сегодня')
button2 = types.KeyboardButton('Завтра')
button3 = types.KeyboardButton('Вчера')
button4 = types.KeyboardButton('/start')
button5 = types.KeyboardButton('/addtask')
button6 = types.KeyboardButton('/help')